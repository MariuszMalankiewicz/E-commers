<?php

$heading = "Nowe produkty";

require("views/dashboards/news.view.php");
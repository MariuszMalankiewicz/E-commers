<?php

$heading = "Kontakt";

require("views/dashboards/contact.view.php");